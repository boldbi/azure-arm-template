from dlt.common import pendulum

GMAIL_GROUP = None
DEFAULT_START_DATE = pendulum.datetime(1970, 1, 1)
DEFAULT_CHUNK_SIZE = 100
