from typing import Callable, Set

from .parser.endpoint_collection import Endpoints


TEndpointFilter = Callable[[Endpoints], Set[str]]
