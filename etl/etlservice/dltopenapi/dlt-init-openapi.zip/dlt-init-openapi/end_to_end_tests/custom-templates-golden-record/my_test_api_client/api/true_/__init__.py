""" Contains methods for accessing the API Endpoints """

import types

from . import false_


class True_Endpoints:
    @classmethod
    def false_(cls) -> types.ModuleType:
        return false_
