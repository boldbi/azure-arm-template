""" Generate a complete client and verify that it is correct """
