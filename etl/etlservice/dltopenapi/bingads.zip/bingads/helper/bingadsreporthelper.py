
def get_campaign_performance_report_request(
        account_id,
        aggregation,
        exclude_column_headers,
        exclude_report_footer,
        exclude_report_header,
        report_file_format,
        return_only_complete_data,
        time, reporting_service, columns):

    report_request = reporting_service.factory.create('CampaignPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Campaign Performance Report"
    scope = reporting_service.factory.create('AccountThroughCampaignReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    report_request.Scope = scope

    #documentation: https://docs.microsoft.com/en-us/advertising/reporting-service/campaignperformancereportcolumn?view=bingads-13
    report_columns = reporting_service.factory.create('ArrayOfCampaignPerformanceReportColumn')
    report_columns.CampaignPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_account_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('AccountPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Account Performance Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfAccountPerformanceReportColumn')
    report_columns.AccountPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_ad_group_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('AdGroupPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Ad Group Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfAdGroupPerformanceReportColumn')
    report_columns.AdGroupPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_conversion_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('ConversionPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Conversion Performance Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfConversionPerformanceReportColumn')
    report_columns.ConversionPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_keyword_performance_report_request(
        account_id,
        aggregation,
        exclude_column_headers,
        exclude_report_footer,
        exclude_report_header,
        report_file_format,
        return_only_complete_data,
        time, reporting_service, columns):

    report_request = reporting_service.factory.create('KeywordPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time

    report_request.ReportName = "Keyword Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfKeywordPerformanceReportColumn')
    report_columns.KeywordPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

# generate budget Summary report request
def get_budget_summary_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('BudgetSummaryReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Budget Summary Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfBudgetSummaryReportColumn')
    report_columns.BudgetSummaryReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_search_query_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('SearchQueryPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Search Query Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfSearchQueryPerformanceReportColumn')
    report_columns.SearchQueryPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_user_location_performance_report_request(
        account_id,
        aggregation,
        exclude_column_headers,
        exclude_report_footer,
        exclude_report_header,
        report_file_format,
        return_only_complete_data,
        time, reporting_service, columns):

    report_request = reporting_service.factory.create('UserLocationPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time

    report_request.ReportName = "User Location Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfUserLocationPerformanceReportColumn')
    report_columns.UserLocationPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_goals_and_funnels_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('GoalsAndFunnelsReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Goals and Funnels Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfGoalsAndFunnelsReportColumn')
    report_columns.GoalsAndFunnelsReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_ad_extension_detail_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('AdExtensionDetailReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Ad Extension Detail Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfAdExtensionDetailReportColumn')
    report_columns.AdExtensionDetailReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_conversion_goals_detail_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('ConversionGoalPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Conversion Goals Detail Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfConversionGoalPerformanceReportColumn')
    report_columns.ConversionGoalPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_geo_location_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('GeoLocationPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Geo Location Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfGeoLocationPerformanceReportColumn')
    report_columns.GeoLocationPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_age_gender_audience_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('AgeGenderAudienceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Age and Gender Audience Report"

    scope = reporting_service.factory.create('AccountReportScope')
    scope.AccountIds = {'long': [account_id]}
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfAgeGenderAudienceReportColumn')
    report_columns.AgeGenderAudienceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request

def get_ad_dynamic_text_performance_report_request(account_id, aggregation, exclude_column_headers, exclude_report_footer, exclude_report_header, report_file_format, return_only_complete_data, time, reporting_service, columns):
    report_request = reporting_service.factory.create('AdDynamicTextPerformanceReportRequest')
    report_request.Aggregation = aggregation
    report_request.ExcludeColumnHeaders = exclude_column_headers
    report_request.ExcludeReportFooter = exclude_report_footer
    report_request.ExcludeReportHeader = exclude_report_header
    report_request.Format = report_file_format
    report_request.ReturnOnlyCompleteData = return_only_complete_data
    report_request.Time = time
    report_request.ReportName = "Ad Dynamic Text Performance Report"

    scope = reporting_service.factory.create('AccountThroughAdGroupReportScope')
    scope.AccountIds = {'long': [account_id]}
    scope.Campaigns = None
    scope.AdGroups = None
    report_request.Scope = scope

    report_columns = reporting_service.factory.create('ArrayOfAdDynamicTextPerformanceReportColumn')
    report_columns.AdDynamicTextPerformanceReportColumn.append([columns])
    report_request.Columns = report_columns

    return report_request






