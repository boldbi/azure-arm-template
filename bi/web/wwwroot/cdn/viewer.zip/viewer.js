var viewerScripts = [];
var viewerStyles = [];
var dashboardElement = "";
var tabObj = "";
var isMultiTabSelected = false;
var isSydjViewer = true;
var ejViewerType = "BoldBIDashboardDesigner";
var dashboardDesignerUrl = "";
var isDefaultViewMarked = false;
var itemLocation ="";
var isMobileView = false;
var multiTabDashboardDetails = "";
var version = "0";
var isAiServiceEnabled = false;
var isWidgetSummarizationEnabled = false;
var isDashboardInsightEnabled = false;
var isBoldAISelected = false;
var isAIEnabledGlobally = false;
var isAiSummariesEnabledGlobally = false;
var environment = "";
window.onload = function () {
	isSydjViewer = !itemLocation.endsWith(".sydx");
	isMobileView = $(window).width() < 768 ? true : false;
	$.ajax({
		type: "GET",
		url: serverApiUrl + "/v5.0/settings/site?key=IsAiServiceEnabled,IsWidgetSummarizationEnabled,IsDashboardInsightEnabled,IsAIEnabled,EnableAiFeature,IsAiSummariesEnabledGlobally",
		headers: {
			"Content-type": "application/json",
			"Authorization": "bearer " + accessToken,
		},
		success: function (data) {
			// Check if data is an array and contains the expected key-value pair
			if (Array.isArray(data) && data.length > 0) {
				
				for (var systemkey in data) {
					
					switch (systemkey.Key) {
						case "IsAiServiceEnabled":
							isAiServiceEnabled = systemkey.Value;
							break;
						case "IsWidgetSummarizationEnabled":
							isWidgetSummarizationEnabled = systemkey.Value;
							break;
						case "IsDashboardInsightEnabled":
							isDashboardInsightEnabled = systemkey.Value;
							break;
						case "IsAIEnabled":
							isBoldAISelected = systemkey.Value;
							break;
						case "EnableAiFeature":
							isAIEnabledGlobally = systemkey.Value;
							break;
						case "IsAiSummariesEnabledGlobally":
							isAiSummariesEnabledGlobally = systemkey.Value;
							break;
					}
				}
			} else {
				console.error("Unexpected response structure:", data);
			}
		},
		error: function () {

		}
	});

	if(isMultiTab){
		$.ajax({
			type: "GET",
			async: false,
			url: serverApiUrl + "/v2.0/dashboards/tabs/" + itemId,
			headers: {
				"Content-type": "application/json",
				"Authorization": "bearer " + accessToken,
			},
			success: function (data) {
				multiTabDashboardDetails = data
			},
			error: function () {

			}
		});
	}
	else{
		$.ajax({
			type: "GET",
			url: serverApiUrl + "/v2.0/items/" + itemId,
			headers: {
				"Content-type": "application/json",
				"Authorization": "bearer " + accessToken,
			},
			success: function (data) {
				version = data.Version
			},
			error: function () {

			}
		});
	}
	if(!isSydjViewer){
		ejViewerType = "ejDashboardViewer";
		viewerScripts = [
			"dashboardservice/v1/scripts/ej.dashboardViewer.web.all.min.js",
			"dashboardservice/v1/scripts/ej.dashboardviewer.all.min.js"
		];

		viewerStyles = [
			"dashboardservice/v1/themes/default-theme/ej.dashboardviewer.all.min.css"
		];
	}
	else{
		ejViewerType = "BoldBIDashboardDesigner";
		if(typeof(designerServiceUrl) == "undefined"){
			try {
				$.get(serverUrl + "/api/system-settings/get-url" , function(data, status){
					dashboardDesignerUrl = data.Data.DesignerServerUrl;				
				});
			}
			catch(err){
				dashboardDesignerUrl = "https://data.syncfusion.io";
			}
		}
		else {
			dashboardDesignerUrl = designerServiceUrl;
		}
		
        viewerScripts = [
            "dashboardservice/v2/scripts/designerlocalization.js",
			"dashboardservice/v2/scripts/jsrender.min.js",
			"dashboardservice/v2/scripts/ej1.common.all.min.js",
			"dashboardservice/v2/scripts/ej2.common.all.min.js",
			"dashboardservice/v2/scripts/ej.dashboarddesigner.min.js",
			"https://www.bing.com/api/maps/mapcontrol"
		];

		viewerStyles = [
			"dashboardservice/v2/themes/ej.designerfont.min.css",
			"dashboardservice/v2/themes/ej1.web.all.min.css",
			"dashboardservice/v2/themes/ej2.partone.web.all.min.css",
			"dashboardservice/v2/themes/ej2.parttwo.web.all.min.css",
			"dashboardservice/v2/themes/ej.designerwidgets.all.min.css",
			"dashboardservice/v2/themes/ej.dashboarddesigner.min.css",
			"dashboardservice/v2/themes/light/boldbi.theme.definition.min.css"
		];
	}

	if (dashboardDesignerUrl.includes("bi/designer")) {
		environment = "onpremise";
	}
	else {
		environment = "cloud";
	}

	loadScripts();
	loadStyles();
};

function loadScripts(){
	if(viewerScripts.length==0){
		if(!isSydjViewer){
			generateReportV1();
		}
		else {
            $.ajax({
                type: "GET",
                url: serverApiUrl + "/V4/dashboards/filter-parameter/" + itemId,
                headers: {
                    "Content-type": "application/json",
                    "Authorization": "bearer " + accessToken,
                },
                success: function (data) {
                    isDefaultViewMarked = data.IsDefaultView;
                    generateReportV2(data);
                },
                error: function () {
                    generateReportV2(filterParameters);
                }
            });
		}
		
		return;
	}
	var currentUrl = viewerScripts.shift();
	var head = document.getElementsByTagName('head')[0];
	var script = document.createElement('script');
	script.type = 'text/javascript';
	script.src = currentUrl;
	if (currentUrl == "https://www.bing.com/api/maps/mapcontrol") {
		script.async = true;
    }
	script.onload = loadScripts;
	head.appendChild(script);
}

function loadStyles(){
	for (var cssFile = 0; cssFile < viewerStyles.length; cssFile++) {
		var fileref=document.createElement("link")
		fileref.setAttribute("rel", "stylesheet")
		fileref.setAttribute("type", "text/css")
		fileref.setAttribute("href", viewerStyles[cssFile])
		document.getElementsByTagName("head")[0].appendChild(fileref)
	}
}

function loadThemeStyles(selectedDashboardTheme){
		viewerStyles = [
           "dashboardservice/v2/themes/" + selectedDashboardTheme + "/boldbi.theme.definition.min.css"
		];
		loadStyles();
}

function generateReportV2(data) {
	if (dashboardDesignerUrl == "") {
		return setTimeout(generateReportV2, 50);
	}

	if(!isMultiTab){
		$("#dashboard").css("display","block");
		$('#dashboard').empty();	
		$('#dashboard').BoldBIDashboardDesigner({
			serviceUrl: dashboardDesignerUrl,
			dataServiceUrl: dashboardDesignerUrl,
			serverUrl: serverApiUrl,
			mode: BoldBIDashboard.Designer.mode.view,
			itemId: itemId,
			dashboardPath: itemId + "/" + version,
			dashboardName: convertUnicodeCharactersInString(reportName),
			theme: dashboardTheme,
			dashboardDescription: convertUnicodeCharactersInString(reportDescription),
			serviceAuthorizationToken: accessToken,
			environment: environment,
			showGetLinkIcon: false,
			viewerSettings: {      
				serviceUrl: serviceUrl 
			},
			filterParameters: (data != null && typeof (data.QueryString) != "undefined") ? decodeURI(data.QueryString) : data,
			enableExport: true,
			enablePrint: false,
			enableFilterOverview: true,
			_isPublic: isPublic,
			actionComplete: "OnActionComplete",
			favoriteSettings: {
				enabled: false
			},
			filterOverviewSettings: {
				showSaveIcon: true,
				showSaveAsIcon: true,
				showViewSavedFilterIcon:false,
			},
			designerAppSettings: {
				cacheSettingServerInfo: dataCache
            },
			_onSaveFilter: "onSaveFilterAction",
			_onSaveAsFilter: "onSaveAsFilterAction",
			_onViewSavedFilters: "openViewSection",
			onBannerIconClick: "onBannerIconClick",
			cdnPath: "dashboardservice\\v2\\scripts\\",
			isAIFeatureEnabled :isAiServiceEnabled,
			isWidgetSummarizationFeatureEnabled :isWidgetSummarizationEnabled,
			isDashboardInsightFeatureEnabled :isDashboardInsightEnabled,
			isBoldAISelected :isBoldAISelected,
			isAIEnabledGlobally :isAIEnabledGlobally,
			isAiSummariesEnabledGlobally : isAiSummariesEnabledGlobally
		});
	}
	else{
		$("#multi-tab-dashboard").css("display","block");
		for (var i = 0; i < Object.keys(multiTabDashboardDetails).length ; i++)
		{
			var header = document.createElement("div")
			header.innerText = convertUnicodeCharactersInString(multiTabDashboardDetails[i].Name)
			document.getElementsByClassName('e-tab-header')[0].appendChild(header)
			var dashboard = document.createElement("div")
			dashboard.setAttribute("data-designer-id","dashboard" + i)
			dashboard.className = "tab-dashboard dashboard-content ";
			dashboard.style.height = "100%"
			document.getElementsByClassName('e-content')[0].appendChild(dashboard)
			var dashboardChild = document.createElement("div")
			dashboardChild.setAttribute("id","dashboard" + i)
			dashboardChild.setAttribute("data-id","dashboard" + multiTabDashboardDetails[i].DashboardId)
			dashboard.appendChild(dashboardChild)		
		}

		for (var i = 0; i < Object.keys(multiTabDashboardDetails).length ; i++)
        {
			var mobHeaderList = document.createElement("li")
			mobHeaderList.setAttribute("data-id","e-content-multi-tab-dashboard_" + i)
			mobHeaderList.setAttribute("id","multi-tab-mobile-header_" + i)
			mobHeaderList.className = "multi-tab-header-list"
			var mobHeaderDiv = document.createElement("div")
			mobHeaderDiv.className = "multi-tab-header-names"
			mobHeaderDiv.innerText = convertUnicodeCharactersInString(multiTabDashboardDetails[i].Name)
			mobHeaderList.appendChild(mobHeaderDiv)
			document.getElementsByClassName("multi-tab-header-list-container")[0].appendChild(mobHeaderList)
        }

		tabObj = new ejs.navigations.Tab({ enableAnimation: false, selected: onAfterSelectedTab });
		tabObj.appendTo('#multi-tab-dashboard');
		selectedTabView();
		resetViewPanel(getDashboardInstance());
	}
	
    if (isDefaultViewMarked) {
		var result = getDashboardInstance();
		result.model.filterOverviewSettings.viewName = convertUnicodeCharactersInString(data.ViewName);
		result.model.filterOverviewSettings.viewId = data.ViewId;
    }
}

 function generateReportV1() {
	$('#dashboard').empty();
	$("#dashboard").ejDashboardViewer({
		accessToken: accessToken,
		serviceUrl: serviceUrl,
		serverUrl: serverUrl,
		dashboardPath: itemId + '/' +version,
		reportName: convertUnicodeCharactersInString(reportName),
		reportDescription: convertUnicodeCharactersInString(reportDescription),
		filterParameters: filterParameters,
		enableExport: true,
		enablePrint: false,
		enableFilterOverview: true,
		_isPublic: isPublic,
		_itemId: itemId,
		allowCommenting: false,
		actionComplete: "OnActionComplete",
		environment: environment,
		favoriteSettings: {
			enabled: false
		},
		filterPanelSettings: {
			showIcon: false,
			showHeader: false,
			filterPanelId: "filter-panel"
		},
		filterOverviewSettings: {
			showSaveIcon: true,
			showSaveAsIcon: true,
			showViewSavedFilterIcon:false,
		},
		onSaveFilter: "onSaveFilterAction",
		onSaveAsFilter: "onSaveAsFilterAction",
		onViewSavedFilters: "openViewSection",
		beforeLayoutRender: "resetViewPanel",
		tabActive: "resetViewPanel",
		_baseUrl: dashboardUrl,
		isAIFeatureEnabled :isAiServiceEnabled,
		isWidgetSummarizationFeatureEnabled :isWidgetSummarizationEnabled,
		isDashboardInsightFeatureEnabled :isDashboardInsightEnabled,
		isBoldAISelected :isBoldAISelected,
		isAIEnabledGlobally : isAIEnabledGlobally,
		isAiSummariesEnabledGlobally : isAiSummariesEnabledGlobally
	});
}




function OpenFilterPanel() {
	var dashboardDOMId = "#" + getDashoardDOMId();
	$('.e-ddl-popup').hide();
	$(dashboardDOMId).click();
	$('#filter-panel').show();
	$(dashboardDOMId).hide();
	var dashboardObj = getDashboardInstance();
	if (dashboardObj.hasFilterPanel == true) {
		$("#filter-panel #validation-message").hide();
		dashboardObj.openFilterPanel();
	} else {
		$("#filter-panel #validation-message").show();
		if(typeof(dashboardObj.closeFilterPanel) != "undefined"){
			dashboardObj.closeFilterPanel();
		}
	}
}


function CloseAllWindows() {
	$('#filter-panel').hide();
	var dashboardDOMId = "#" + getDashoardDOMId();
	$(dashboardDOMId).show();
	var data = getDashboardInstance();
	data.closeAllWindows();
	if(typeof(data.closeFilterPanel) != "undefined"){
		data.closeFilterPanel();
	}
}

function OnActionComplete(args) {
	if (args.eventType === "maximizeDialogOpen" || args.eventType === "exportDialogOpen" || args.eventType === "filterOverViewOpen" || args.eventType === "informationOpen" || args.eventType === "getLinkDialogOpen")
	{
		try {
			var data = {
				Action: "HideBackButton",
				Data: JSON.stringify(args.eventType)
			}
			invokeCSharpAction(JSON.stringify(data));
		}
		catch (err)
		{ }
	}
	else if (args.eventType === "maximizeDialogClose" || args.eventType === "exportDialogClose" || args.eventType === "filterOverViewClose" || args.eventType === "informationClose" || args.eventType === "exportCompleted" || args.eventType === "clearAllFilter" || args.eventType === "clearIndividualFilter" || args.eventType == "getLinkDialogClose") {
		try {
			var data = {
				Action: "ShowBackButton",
				Data: JSON.stringify(args.eventType)
			}
			invokeCSharpAction(JSON.stringify(data));
		}
		catch (err)
		{ }
    }
    else if (args.eventType === "interactionCompleted" && !isDefaultViewMarked) {
        var widgetFilterQuery = args.source.data.encryptedData;
        var filterRequest = { ItemId: itemId, QueryString: widgetFilterQuery };

        $.ajax({
            type: "POST",
            url: serverApiUrl + "/V4/dashboards/views/autosave",
            headers: {
                "Content-type": "application/json",
                "Authorization": "bearer " + accessToken,
            },
            data: JSON.stringify(filterRequest)
        });
    }else if (args.eventType === "layoutRendered" && isMultiTab && !isMultiTabSelected){
		applyDashboardTheme();
		if (!isMobileView) {
			tabObj.select(tabObj.selectedItem);
			isMultiTabSelected = true;
		}
	}else if (args.eventType === "renderLayout" && isMultiTab){
		setSpaceForTitle();
	}
}

function ApplyView(filterQuery) {
	if(isMultiTab){
		$("#" + $("#multi-tab-content .tab-dashboard.e-item.e-active").attr("data-designer-id")).data(ejViewerType).option("filterParameters", filterQuery);
	}else{
		$("#dashboard").data(ejViewerType).option("filterParameters", filterQuery);
	}
}

function onSaveFilterAction(args) {
	try {
		if(isMultiTab){
			args.dashboardId = $("#multi-tab-content .tab-dashboard.e-item.e-active").attr("data-designer-id");
		}
		var data = {
			Action: "saveView",
			Data: JSON.stringify(args)
		}
		invokeCSharpAction(JSON.stringify(data));
	} catch (err) {  }
}

function onSaveAsFilterAction(args) {
	try {
		var data = {
			Action: "saveViewAs",
			Data: JSON.stringify(args)
		}
		invokeCSharpAction(JSON.stringify(data));
	} catch (err) { }
}

function DecryptFilterParameter(queryString) {
	var viewerObj = getDashboardInstance();
	if (viewerObj) {
		return JSON.stringify(viewerObj._parseParameterQuery(queryString));
	}
	return "";
}

function ClearFilterOverView(id) {
	var data = getDashboardInstance();
	if (data.model.filterOverviewSettings.viewId === id) {
		data.model.filterOverviewSettings.viewName = null;
		data.model.filterOverviewSettings.viewId = null;
	} 
}

function resetViewPanel(args) {
	try {
		var parameters = {
			model: args.model
		};

		var data = {
			Action: "resetViewPanel",
			Data: JSON.stringify(parameters)
		};

		invokeCSharpAction(JSON.stringify(data));
	} catch (err) { }
	
	if(!isMultiTab){
		$('#dashboard').data(ejViewerType).model.filterOverviewSettings.viewName = null;
		$('#dashboard').data(ejViewerType).model.filterOverviewSettings.viewId = null;
	}
}

function onBannerIconClick(arg) {
	var dashboardViewerInstance = getDashboardInstance();
	if (typeof (arg.name) != "undefined") {
		arg.menuItems = arraySlice(arg.menuItems, "id", "dashboard-info");
		switch (arg.name.toLowerCase()) {
			case "link":
					var dashboardLink = dashboardUrl;
					var dashboardViewerObj = dashboardViewerInstance;
					var filterObj = dashboardViewerObj.getCurrentFilters();
					if (filterObj != null && filterObj.isInitialFilter != null && !filterObj.isInitialFilter) {
						dashboardLink += "?" + filterObj.encryptedData;
					}
					$(".link-field").val(dashboardLink);
					$(".get-link-popup").show();
				break;
			case "theming":
				dashboardTheme = arg.selectedTheme;
                dashboardViewerInstance.applyDashboardTheme(arg.selectedTheme);
				loadThemeStyles(arg.selectedTheme);
				if (isMultiTab) {
                    applyDashboardTheme();
                }

				try {				
					var parameters = {
						backgroundcolor:  dashboardViewerInstance.modules.themeHelper.getBannerBackground(),
						theme : arg.selectedTheme
					};

					var data = {
						Action: "ApplyTheme",
						Data: JSON.stringify(parameters)
					}

					invokeCSharpAction(JSON.stringify(data));
				}
				catch (err)
				{ 
					
				}

				break;
			default:
				break;
		}
	}
}

function arraySlice(arr, key, value) {

	arr.forEach(function (item, index, object) {
		if (item[key] === value) {
			object.splice(index, 1);
		}
	}.bind(this));
	return arr;
};

$(document).on("click", ".copy-link-btn", function () {
	$(".link-field").select();
	document.execCommand("copy");
});

$(document).on("click", ".close-get-link", function () {
	$(".get-link-popup").hide();
});

/*********************** BELOW CODES ADDED FOR MULTI-TAB ***********************************/

function onAfterSelectedTab(tabId) {
	if(!isMobileView){
		$("#multi-tab-dashboard .e-tab-header .e-toolbar-item .e-tab-text").removeClass("active-font-color");
		$("#multi-tab-dashboard .e-tab-header .e-toolbar-item.e-active .e-tab-text").addClass("active-font-color");
		for (var i = 0; i < Object.keys(multiTabDashboardDetails).length; i++) {
			$("#e-content-multi-tab-dashboard_" + i).hide();
			if ($("#multi-tab-dashboard .e-content .dashboard-content.e-active").attr("data-designer-id") == "dashboard" + i) {
				$("#multi-tab-content #e-content-multi-tab-dashboard_" + i).show();
				dashboardElement = "#dashboard" + i ;
				var dashboardViewerInstance = getDashboardInstance();
				if (typeof (dashboardViewerInstance) == "undefined") {
					loadDesignerModel(multiTabDashboardDetails[i], "dashboard" + i);
				}
			}
		}
	}else{
		for (var i = 0; i < Object.keys(multiTabDashboardDetails).length; i++) {
			if (("e-content-multi-tab-dashboard_" + i) == tabId) {
				$("#multi-tab-dashboard .e-tab-header .e-items.e-toolbar-items").find(".e-active").removeClass("e-active");
				$("#multi-tab-header-container .multi-tab-header-list-container").find(".e-active").removeClass("e-active");
				$("#multi-tab-content").find(".tab-dashboard.e-active").removeClass("e-active");
				$("#multi-tab-header-container .multi-tab-header-list-container #multi-tab-mobile-header_" + i).addClass("e-active");
				$("#multi-tab-dashboard .e-tab-header #e-item-multi-tab-dashboard_" + i).addClass("e-active");
				$("#multi-tab-dashboard .e-toolbar-item .e-tab-text").removeClass("active-font-color");
				$("#multi-tab-dashboard .e-toolbar-item.e-active .e-tab-text").addClass("active-font-color");
				$("#multi-tab-content #e-content-multi-tab-dashboard_" + i).show();
				$("#multi-tab-content #e-content-multi-tab-dashboard_" + i).addClass("e-active");
				dashboardElement = "#dashboard" + i ;
				var dashboardViewerInstance = getDashboardInstance();
				if (typeof (dashboardViewerInstance) == "undefined") {
					loadDesignerModel(multiTabDashboardDetails[i], "dashboard" + i);
				}
			} else {
				$("#multi-tab-content #e-content-multi-tab-dashboard_" + i).hide();
			}
		}
	}

	resetViewPanel(getDashboardInstance());
	resizehWidgets();
	setSpaceForTitle();
}


$(document).on("click", "#multi-tab-header-container .multi-tab-header-list-container .multi-tab-header-list", function () {
    onAfterSelectedTab($(this).attr("data-id"));
    $(".blur-container").hide();
    $("#multi-tab-header-container").hide();
});

function loadDesignerModel(itemDetail, id) {
    $('#' + id).BoldBIDashboardDesigner({
        serviceUrl: dashboardDesignerUrl,
        dataServiceUrl: dashboardDesignerUrl,
        serverUrl: serverApiUrl,
        mode: BoldBIDashboard.Designer.mode.view,
        itemId: itemDetail.DashboardId,
		allowCommenting: false,
		theme: dashboardTheme,
        dashboardPath: itemDetail.DashboardId + "/" + itemDetail.Version,
		dashboardName: convertUnicodeCharactersInString(itemDetail.Name),
		environment: environment,
        dashboardSettings: {
            isMultiTab: true,
            parentId: itemId
        },
		dashboardDescription: convertUnicodeCharactersInString(itemDetail.Description),
        serviceAuthorizationToken: accessToken,
		enableExport: true,
		enablePrint: false,
		enableFilterOverview: true,
		_isPublic: isPublic,
		actionComplete: "OnActionComplete",
		_favoriteSettings: {
            enabled: false,
            isFavorite: false
        },
		filterOverviewSettings: {
            showSaveIcon: true,
			showSaveAsIcon: true,
			showViewSavedFilterIcon:false,
		},
		designerAppSettings: {
			cacheSettingServerInfo: dataCache
		},
        _onSaveFilter: "onSaveFilterAction",
        _onSaveAsFilter: "onSaveAsFilterAction",
        _onViewSavedFilters: "openViewSection",
		onBannerIconClick: "onBannerIconClick",	
		showGetLinkIcon: false,
		viewerSettings: {      
			serviceUrl: serviceUrl 
		},
		cdnPath: "dashboardservice\\v2\\scripts\\",
		isAIFeatureEnabled :isAiServiceEnabled,
		isWidgetSummarizationFeatureEnabled :isWidgetSummarizationEnabled,
		isDashboardInsightFeatureEnabled :isDashboardInsightEnabled,
		isBoldAISelected :isBoldAISelected,
		isAIEnabledGlobally :isAIEnabledGlobally,
		isAiSummariesEnabledGlobally : isAiSummariesEnabledGlobally
    });

	if(isMobileView){
		dashboardElement = "#" + $("#multi-tab-dashboard .e-content .dashboard-content.e-active").attr("data-designer-id");
        setSpaceForTitle();
        $("#multi-tab-mobile-menu").show();
	}
	else {
		dashboardElement = "#" + id;
	}
}

function selectedTabView() {
    if (!isMobileView) {
		$("#multi-tab-header-container").hide();
		$("#multi-tab-dashboard").height();
		$("#multi-tab-content").width($(window).width());
        $("#multi-tab-content").height($(window).height() - $(".e-tab-header.e-control.e-toolbar.e-lib.e-keyboard").height());
		$("#multi-tab-dashboard .e-toolbar-item .e-tab-text").removeClass("active-font-color");
		$("#multi-tab-dashboard .e-toolbar-item.e-active .e-tab-text").addClass("active-font-color");

    } else {
		
		$("#multi-tab-dashboard .e-tab-header.e-control.e-toolbar.e-lib.e-keyboard").hide();
        $("#multi-tab-content").width($(window).width());
        $("#multi-tab-content").height($(window).height());
		$("#multi-tab-mobile-menu").hide();
        $("#multi-tab-header-container").height($(window).height());
        $(".blur-container").height($(window).height());

        for (var i = 0; i < Object.keys(multiTabDashboardDetails).length; i++) {
            $("#multi-tab-content #e-content-multi-tab-dashboard_" + i).hide();
        }

		$("#multi-tab-content #e-content-multi-tab-dashboard_0").addClass("e-active");
		$("#multi-tab-content #e-content-multi-tab-dashboard_0").show();
		$("#multi-tab-header-container #multi-tab-mobile-header_0").addClass("e-active");
		
    }
	 
	loadDesignerModel(multiTabDashboardDetails[0], "dashboard0");
}

function getDashboardInstance() {
    var instance = "";
    if (isMultiTab) {
		instance = $("#" + $("#multi-tab-dashboard .e-content .dashboard-content.e-active").attr("data-designer-id")).data("BoldBIDashboardDesigner");
    } else {
        instance = $('#dashboard').data("BoldBIDashboardDesigner");
    }

    return instance;
}

function applyDashboardTheme() {
    var dashboardInstance = getDashboardInstance();
    setDefaultTheme(dashboardInstance.modules.themeHelper.getBannerBackground(), dashboardInstance.modules.themeHelper.getBannerTextColor(), dashboardInstance.modules.themeHelper.getBannerIconColor());
    for (var i = 0; i < $(".e-item.e-toolbar-item").length; i++) {
		if ($("#multi-tab-content .tab-dashboard.e-item.e-active").attr("data-designer-id") != "dashboard" + i) {
            var dashboardViewerInstance = $("#dashboard" + i).data("BoldBIDashboardDesigner");
			if (typeof (dashboardViewerInstance) != "undefined") {
				dashboardViewerInstance.applyDashboardTheme(dashboardTheme);
            }
        }
    }
}

function setDefaultTheme(bgColor, textColor, iconColor) {
	if (isMobileView) {
        $("#multi-tab-header-container").css("background", bgColor);
        $("#multi-tab-header-container .multi-tab-header-names").css("color", textColor);
		$("#multi-tab-mobile-menu .su-mobile-menu-icon").css("color", iconColor);
    } else {
        $("#multi-tab-dashboard .e-tab-header.e-control.e-toolbar.e-lib.e-keyboard").css("color", iconColor);
        $("#multi-tab-dashboard .e-toolbar-item .e-tab-text").css("color", textColor);
        $("#multi-tab-dashboard .e-toolbar-item.e-active .e-tab-text").addClass("active-font-color");
        $("#multi-tab-dashboard").css("background", bgColor);
    }
}

function beforeBannerIconRender(event) {
    var dashboardViewerInstance = getDashboardInstance();
    if (isMultiTab) {
        setDefaultTheme(dashboardViewerInstance.modules.themeHelper.getBannerBackground(), dashboardViewerInstance.modules.themeHelper.getBannerTextColor(), dashboardViewerInstance.modules.themeHelper.getBannerIconColor());
    }
}

$(document).on("click", ".blur-container", function () {
    $(".blur-container").hide();
    $("#multi-tab-header-container").hide();
});

$(document).on("click","#multi-tab-mobile-menu", function (e) {
	$(".blur-container").show();
	$("#multi-tab-header-container").show();
	if (dashboardTheme.toLowerCase() == "light") {
		$("#multi-tab-header-container").addClass("light-theme").removeClass("dark-theme");
	} else {
		$("#multi-tab-header-container").addClass("dark-theme").removeClass("light-theme");
	}
});




function resizeTab(){
	resizeRenderLayout();
	dashboardElement = "#" + $("#multi-tab-dashboard .e-content .dashboard-content.e-active").attr("data-designer-id");
	if (isMobileView) {
		$("#multi-tab-mobile-menu").show();
		$("#multi-tab-dashboard .e-tab-header").hide();
		$("#multi-tab-header-container").height($(window).height());
        $(".blur-container").height($(window).height());
		var selectedTabId = $('#multi-tab-dashboard .e-tab-header .e-active').attr('aria-controls');
		if(selectedTabId !== undefined){
			for (var i = 0; i < Object.keys(multiTabDashboardDetails).length; i++) {
				if ($("#multi-tab-mobile-header_" + i).attr("data-id") == selectedTabId) {
					$("#multi-tab-header-container .multi-tab-header-list-container #multi-tab-mobile-header_" + i).addClass("e-active");
				}else {
					$("#multi-tab-mobile-header_" + i).removeClass("e-active");
				}
			}
		}
    } else{
		$(".blur-container").hide();
		$("#multi-tab-header-container").hide();
		$("#multi-tab-mobile-menu").hide();
		$("#multi-tab-dashboard .e-tab-header").show();
		if($("#multi-tab-header-container .multi-tab-header-list-container").children(".e-active").index() >= 0 ){
			tabObj.select($("#multi-tab-header-container .multi-tab-header-list-container").children(".e-active").index())
		}
	}

	setSpaceForTitle();
	applyDashboardTheme();
}

function resizeRenderLayout(){
	if(isMobileView){
		$("#multi-tab-content").height($(window).height());
		$("#multi-tab-content .tab-dashboard.e-item").height($(window).height());
	}
	else{
		$("#multi-tab-content").height($(window).height()- $("#multi-tab-dashboard .e-tab-header.e-control.e-toolbar.e-lib.e-keyboard").height());
		$("#multi-tab-content .e-item").height($(window).height() - $("#multi-tab-dashboard .tab-dashboard.e-tab-header.e-control.e-toolbar.e-lib.e-keyboard").height());
	}

	$("#multi-tab-content").width($(window).width())
	$("#multi-tab-dashboard .e-content .e-item").children().width($(window).width());
}

function resizehWidgets(){
	var data = getDashboardInstance();
	data.resizeDashboard();
}

$(window).bind('resizeEnd', function() {
    isMobileView = $(window).width() < 768 ? true : false;
	if(isMultiTab){
		resizeTab();
	}
	resizehWidgets();
});

$(window).resize(function() {
	if(this.resizeTO) clearTimeout(this.resizeTO);
	this.resizeTO = setTimeout(function() {
		$(this).trigger('resizeEnd');
	}, 150);
});

function setSpaceForTitle(){
	isMobileView = $(window).width() < 768 ? true : false;
	if(isMobileView){

		$(dashboardElement + "_bannerPanel .bbi-dashboard-banner-title").css({ "position": "relative", "left": "30px" });
		$(dashboardElement + "_bannerPanel .bbi-dynamic-title-container").css({ "left": "30px" });
	}else{

		$(dashboardElement + "_bannerPanel .bbi-dashboard-banner-title").css({ "position": "relative", "left": "0px" });
		$(dashboardElement + "_bannerPanel .bbi-dynamic-title-container").css({ "left": "0px" });
	}
}

function getDashoardDOMId(){
	if(isMultiTab){
		return $("#multi-tab-content .tab-dashboard.e-item.e-active").attr("data-designer-id");
	}
	
	return 'dashboard';
}

function convertUnicodeCharactersInString(reportName){
	var name = $("<span></span>").html(reportName).text();
	return name;
} 